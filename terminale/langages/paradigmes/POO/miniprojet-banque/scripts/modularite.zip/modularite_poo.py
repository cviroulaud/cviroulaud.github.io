#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Date de création Fri Sep 11 08:42:32 2020

@auteur: Christophe Viroulaud
"""


from mod_temperature import Temperature
help(Temperature)