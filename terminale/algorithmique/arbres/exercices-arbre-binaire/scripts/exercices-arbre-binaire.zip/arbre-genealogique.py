#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Date de création Mon Feb  1 10:04:59 2021

@auteur: Christophe Viroulaud
"""


# Pour respecter la numérotation de Sosa-Stradonitz la première cellule est laissée vide
macron = ["", "Emmanuel Macron", "Jean-Michel Macron", "Françoise Noguès",
          "André-Henri Macron", "Jacqueline Robertson", "Jean Noguès",
          "Germaine Arribet", "Henri Eugène Macron", "Marie Adèle Bosseur",
          "Georges William Robertson", "Suzanne Leblond", "Fabien Noguès",
          "Esther Mas", "Ernest Arribet", "Marie Madeleine Millet"]

