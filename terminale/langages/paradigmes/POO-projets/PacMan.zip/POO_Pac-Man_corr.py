# -*- coding: utf-8 -*-
"""
Created on Thu Aug 27 17:21:09 2020
@author: A-G
"""


import random, time

# Les paramètres explicites de chacun des objets permettent éventuellement de
# continuer la partie si Pac-Man sort vainqueur.

class Fruit:
    """Chaque fruit mangé rapporte 1 point."""
    def __init__(self, nb):
        self.nb = nb    # nombre de fruits


class Gomme:
    """Chaque gomme mangée rend le fantôme vulnérable pendant 2 tours."""
    def __init__(self, nb):
        self.nb = nb    # nombre de gommes


class PacMan:
    """Notre Héros !"""
    def __init__(self, vies, pts):
        self.nb_vies = vies
        self.points = pts

    def ajouter_points(self, val):
        """Une vie supplémentaire est gagnée par tranche de 15 points."""
        self.points += val
        if self.points >= 15:
            bonus = self.points // 15
            print("-*/\*-   Bonus ! Nombre de vies gagnées :", bonus, "  -*/\*-")
            self.nb_vies += bonus
            print("Il en reste " + str(self.nb_vies) + ".")
            self.points = self.points % 15

    def mange_fruit(self, fruit, fantome):
        fruit.nb -= 1
        fantome.mangeable -= 1
        print("Pac-Man a mangé un fruit, il en reste " + str(fruit.nb) + ".")
        self.ajouter_points(1)

    def mange_gomme(self, gomme, fantome):
        gomme.nb -= 1
        fantome.mangeable = 2
        print("Pac-Man a mangé une gomme, il en reste " + str(gomme.nb) + ".")

    def mange_fantome(self, fantome):
        fantome.mort = True
        print("YES !!!   Pac-Man a mangé le fantôme !")
        self.ajouter_points(10)

    def inactif(self, fantome):
        fantome.mangeable -= 1
        print("Pac-Man n'a rien rencontré.")

    def jouer(self, fruit, gomme, fantome):
        rencontres = ["rien", "fruit"]
        if gomme.nb > 0:
            rencontres += ["gomme"]
        if fantome.mangeable > 0:
            rencontres += ["fantome"]

        choix = random.choice(rencontres)
        if choix == "fruit":
            self.mange_fruit(fruit, fantome)
        if choix == "gomme":
            self.mange_gomme(gomme, fantome)
        if choix == "fantome":
            self.mange_fantome(fantome)
        if choix == "rien":
            self.inactif(fantome)


class Fantome:
    """Les dévoreurs de Pac-Man... mangés, ils rapportent 10 points !"""
    def __init__(self):
        self.mangeable = 0
        self.mort = False

    def manger_pacman(self, pacman):
        pacman.nb_vies -= 1
        print("OUPS...   Le fantôme a mangé Pac-Man...")
        if pacman.nb_vies > 1:
            print("Encore", pacman.nb_vies, "vies !")
        if pacman.nb_vies == 1:
            print("Encore 1 vie !")

    def inactif(self):
        if self.mort:
            self.mort = False
            self.mangeable = 0
            print("Pause pour le fantôme : il ressuscite ;-) ")
        else:
            print("Le fantôme n'a rien rencontré.")

    def jouer(self, pacman, fruit):
        rencontres = ["rien", "rien", "rien"]
        if self.mangeable <= 0 and fruit.nb > 0:
            rencontres += ["pacman"]

        choix = random.choice(rencontres)
        if choix == "rien":
            self.inactif()
        if choix == "pacman":
            self.manger_pacman(pacman)


# Initialisation des objets

pacman = PacMan(3, 0)
fantome = Fantome()
fruit = Fruit(10)
gomme = Gomme(4)

# Boucle principale
# Fin de la partie si Pac-Man a épuisé toutes ses vies ou s'il
# parvient à manger tous les fruits

while pacman.nb_vies > 0 and fruit.nb > 0:
    pacman.jouer(fruit, gomme, fantome)
    fantome.jouer(pacman, fruit)
    time.sleep(0.5)    # petite pause dans l'exécution du script
    print()

txt_pt = str(pacman.points) + " points"
if pacman.points == 0:
    txt_pt = "0 point"

if pacman.nb_vies == 0:
    print("Pac-Man a perdu avec", txt_pt, "! Victoire des fantômes...")
else:
    print("Victoire de Pac-Man avec", txt_pt, "! Tous les fruits ont été mangés.")
