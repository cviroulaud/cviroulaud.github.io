#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   Wednesday 16 February 2022 15:22
"""
from constantes import *


def verifier_coordonnees(ligne: int, colonne: int) -> bool:
    """
    vérifie si les coordonnées (ligne et colonne) sont dans la grille
    Les coordonnées doivent vérifier:
        0 <= ligne < TAILLE
        0 <= colonne < TAILLE
    Args:
        ligne (int): ligne choisie
        colonne (int): colonne choisie

    Returns:
        bool: True si coordonnées correctes
    """
    return ligne >= 0 and ligne < TAILLE and colonne >= 0 and colonne < TAILLE


def verifier_gagnant(grille: list) -> bool:
    """
    vérifie si la partie est terminée
    en cherchant si au moins une case est encore allumée:
    Une case allumée contient la constante ON
    Une case éteinte contient la constante OFF

    Args:
        grille (list): grille de jeu

    Returns:
        bool: True si gagné
    """
    # parcourt la grille jusqu'à trouver une case allumée
    for i in range(TAILLE):
        for j in range(TAILLE):
            # une case (au moins) est allumée: perdu
            if grille[i][j] == ON:
                return False
    # toutes les cases sont éteintes
    return True
