#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   2021/08/18 11:58:32
"""

from math import cos, sin, degrees, pi

angle = pi/2
print(f"en degré: {degrees(angle)}, \ncos: {cos(angle)},\nsin: {sin(angle)}")
