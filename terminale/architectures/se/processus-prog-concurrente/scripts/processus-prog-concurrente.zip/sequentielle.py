#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   Jeudi 21 Octobre 2021 21:04
"""


def f1():
    for _ in range(5):
        print("appel 1")


def f2():
    for _ in range(5):
        print("appel 2")


f1()
f2()
