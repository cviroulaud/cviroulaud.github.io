#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   Lundi 25 Octobre 2021 14:36
"""

tab = [0, 1, 2, 3, 4, 5]

for i in range(len(tab)):
    tab[i] = tab[i]**2

print(tab)