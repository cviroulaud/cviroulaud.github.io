#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   Jeudi 31 Mars 2022 09:06
"""
import tkinter
from tkinter import ttk
from random import randint

TAILLE = 20
DIM = 30
NB_POMMES = 10
# N E S O
DEPLACEMENTS = ((0, -1), (1, 0), (0, 1), (-1, 0))


def deplacer_snake(event):
    """
    effectue le changement de direction
    pas de retour arrière possible
    """
    global dpct
    if event.keysym == "Up" and dpct != DEPLACEMENTS[2]:
        dpct = DEPLACEMENTS[0]
    elif event.keysym == "Right" and dpct != DEPLACEMENTS[3]:
        dpct = DEPLACEMENTS[1]
    elif event.keysym == "Down" and dpct != DEPLACEMENTS[0]:
        dpct = DEPLACEMENTS[2]
    elif event.keysym == "Left" and dpct != DEPLACEMENTS[1]:
        dpct = DEPLACEMENTS[3]


def creer_pomme(pommes: list) -> None:
    """
    crée une pomme si le tableau n'est pas complet
    et en vérifiant qu'il n'y ait pas de superposition
    """
    if len(pommes) < NB_POMMES:
        # création pomme
        pomme = ...
        # vérification superposition de 2 pommes
        while pomme in pommes:
            pomme = ...
        # ajout pomme
        pommes.append(...)


def dessiner_pommes(pommes: list) -> None:
    """
    Affiche toutes les pommes sur le plateau
    """
    for i in range(len(pommes)):
        col = pommes[i]["col"]
        lig = pommes[i]["lig"]
        canevas.create_text(col*DIM,
                            lig*DIM,
                            fill="red",
                            text=pommes[i]["val"])


def avancer_serpent(serpent: list) -> None:
    """
    avance chaque anneau d'un cran

    Args:
        coord_serpent (list): les coordonnées des anneaux du serpent
    """
    for i in range(len(serpent)-1, 0, -1):
        serpent[i]["col"] = serpent[...]["col"]
        serpent[...][...] = serpent[...]["lig"]

    # nouvelles coordonnées de la tête (avec changement éventuel)
    serpent[0]["col"] = serpent[0]["col"]+dpct[0]
    serpent[0]["lig"] = serpent[0]["lig"]+dpct[1]


def inserer_pomme(serpent: list) -> None:
    """
    place la pomme dans le serpent
    """    
    i = len(serpent)-1
    while i > 0 and serpent[i]["val"] < ...:
        # inversion des 2 anneaux consécutifs
        serpent[i]["val"], serpent[i-1]["val"] = ...
        i = i-1


def manger_pomme(serpent: list, pommes: list) -> None:
    # position tête du serpent
    col = serpent[0]["col"]
    lig = ...
    for i in range(len(pommes)):
        # vérifie si la tête est sur une pomme
        if pommes[i]["col"] == col and ...:
            # supprime la pomme mangée du tableau
            pomme = pommes.pop(i)
            # récupère le sens de la queue
            dx = serpent[len(serpent)-1]["col"]-serpent[len(serpent)-2]["col"]
            dy = serpent[len(serpent)-1]["lig"]-serpent[len(serpent)-2]["lig"]

            # ajoute la pomme à la fin du serpent
            serpent.append({"col": serpent[len(serpent)-1]["col"]+dx,
                            "lig": ...,
                            "val": ...})
            # positionne la pomme dans le serpent
            inserer_pomme(serpent)
            # la pomme est placée, inutile de parcourir la fin du tableau
            break


def dessiner_anneaux(serpent: list) -> None:
    """
    affiche le serpent
    """
    for i in range(len(serpent)):
        col = serpent[i]["col"]
        lig = serpent[i]["lig"]
        canevas.create_text(col*DIM,
                            lig*DIM,
                            fill="blue",
                            text=serpent[i]["val"])


def verif_croisement(serpent: list) -> bool:
    """
    vérifie si le serpent se croise lui même

    Args:
        coord_serpent (list): les coordonnées des anneaux du serpent

    Returns:
        bool: True si croisement
    """
    for i in range(1, len(serpent)):
        if serpent[i]["col"] == serpent[0]["col"] and \
                serpent[i]["lig"] == serpent[0]["lig"]:
            return True
    return False


def verif_sortie(serpent: list) -> bool:
    """
    vérifie si le serpent sort de la zone

    Args:
        coord_serpent (list): les coordonnées du serpent

    Returns:
        bool: True si sortie
    """
    if serpent[0]["col"] < 0 or \
            serpent[0]["col"] >= TAILLE or \
            serpent[0]["lig"] < 0 or \
            serpent[0]["lig"] >= TAILLE:
        return True
    return False


def jeu(fenetre, canevas, serpent: list, pommes: list):
    canevas.delete("all")
    creer_pomme(pommes)
    dessiner_pommes(pommes)
    avancer_serpent(serpent)
    manger_pomme(serpent, pommes)
    dessiner_anneaux(serpent)
    if not verif_croisement(serpent) and not verif_sortie(serpent):
        fenetre.after(500, jeu, fenetre, canevas, serpent, pommes)
    else:
        # fin du jeu
        canevas.create_text(DIM*TAILLE//2, DIM*TAILLE//2,
                            text="GAME OVER",
                            font="Arial 36",
                            tag="gameover")
        fenetre.unbind("<Right>")
        fenetre.unbind("<Left>")
        fenetre.unbind("<Up>")
        fenetre.unbind("<Down>")


# principal
fenetre = tkinter.Tk()
fenetre.title("Snake")

canevas = tkinter.Canvas(fenetre, width=TAILLE*DIM, height=TAILLE*DIM)
canevas.pack()

fenetre.bind("<Right>", deplacer_snake)
fenetre.bind("<Left>", deplacer_snake)
fenetre.bind("<Up>", deplacer_snake)
fenetre.bind("<Down>", deplacer_snake)

pommes = []
initial = TAILLE//2
serpent = [{"col": initial, "lig": initial, "val": 0},
           {"col": initial+1, "lig": initial, "val": 1}]
dpct = DEPLACEMENTS[1]
jeu(fenetre, canevas, serpent, pommes)


# dernière ligne du programme: met à jour les variables
fenetre.mainloop()
