#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   Wednesday 16 February 2022 12:21
"""
from fonctions import *
from fonctions_verif import *

# initialisation grille
grille = initialiser_grille()

# boucle de jeu
while not verifier_gagnant(grille):
    # afficher la grille dans la console
    afficher_grille(grille)
    # demande des coordonnées au joueur
    ligne, colonne = choisir_case()

    # modifie le plateau si les coordonnées sont acceptables
    if verifier_coordonnees(ligne, colonne):
        inverser_lumieres(grille, ligne, colonne)
    else:
        print("Coordonnées non conformes.")

# fin du jeu
print("gagné!")
