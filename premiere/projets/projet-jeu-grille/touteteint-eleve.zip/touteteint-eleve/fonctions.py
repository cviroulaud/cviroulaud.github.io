#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   Wednesday 16 February 2022 12:22
"""
from random import randint
from constantes import *
from fonctions_verif import *


def initialiser_grille() -> list:
    """
    crée la grille de jeu de départ
    Les cases allumées sont choisies aléatoirement

    Returns:
        list: grille de départ
    """
    return [[randint(0, 1) for _ in range(TAILLE)] for _ in range(TAILLE)]


def afficher_grille(grille: list) -> None:
    """
    affichage de la grille dans la console

    Args:
        grille (list): tableau
    """
    horizontal = "-"*(TAILLE-1)*3
    print(horizontal)

    for i in range(TAILLE):
        ligne = "|"
        for j in range(TAILLE):
            ligne = ligne + str(grille[i][j])+"|"
        print(ligne)
        print((horizontal))


def choisir_case() -> tuple:
    ligne = int(input("ligne (entre 0 et "+str(TAILLE-1)+"): "))
    colonne = int(input("colonne (entre 0 et "+str(TAILLE-1)+"): "))
    return (ligne, colonne)


def inverser_lumieres(grille: list, x: int, y: int) -> None:
    """
    inverse la case choisie et celles autour

    Args:
        grille (list): le tableau de jeu
        x (int): ligne choisie
        y (int): colonne choisie
    """
    # DELTA contient les déplacements autour de la case choisie
    for dx, dy in DELTA:
        ligne = x + dx
        colonne = y + dy
        # vérifie si on est dans la grille
        if verifier_coordonnees(ligne, colonne):
            # inversion
            if grille[ligne][colonne] == ON:
                grille[ligne][colonne] = OFF
            else:
                grille[ligne][colonne] = ON
