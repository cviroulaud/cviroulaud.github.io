# -*- coding: utf-8 -*-
"""
Created on Thu Aug 27 17:21:09 2020
@author: A-G
"""


import random, time

# Les paramètres explicites de chacun des objets permettent éventuellement de
# continuer la partie si Pac-Man sort vainqueur.

class Fruit:
    """Chaque fruit mangé rapporte 1 point."""
    def __init__(self, nb):
        self.nb = nb    # nombre de fruits


class Gomme:
    """Chaque gomme mangée rend le fantôme vulnérable pendant 2 tours."""
    def __init__(self, nb):
        self.nb = nb    # nombre de gommes


class PacMan:
    """Notre Héros !"""
    def __init__(self, vies, pts):
        self.nb_vies = vies
        self.points = pts

    def mange_fruit(self, fruit, fantome):
        fruit.nb -= 1
        fantome.mangeable -= 1
        print("Pac-Man a mangé un fruit, il en reste " + str(fruit.nb) + ".")
        self.points += 1

    def mange_gomme(self, gomme, fantome):
        gomme.nb -= 1
        fantome.mangeable = 2
        print("Pac-Man a mangé une gomme, il en reste " + str(gomme.nb) + ".")

    def mange_fantome(self, fantome):
        fantome.mort = True
        print("YES !!!   Pac-Man a mangé le fantôme !")
        self.points += 10

    def inactif(self, fantome):
        fantome.mangeable -= 1
        print("Pac-Man n'a rien rencontré.")

    def jouer(self, fruit, gomme, fantome):
        rencontres = ["rien", "fruit"]
        if gomme.nb > 0:
            rencontres += ["gomme"]
        if fantome.mangeable > 0:
            rencontres += ["fantome"]

        choix = random.choice(rencontres)
        if choix == "fruit":
            self.mange_fruit(fruit, fantome)
        if choix == "gomme":
            self.mange_gomme(gomme, fantome)
        if choix == "fantome":
            self.mange_fantome(fantome)
        if choix == "rien":
            self.inactif(fantome)



# Initialisation des objets



# Boucle principale
# Fin de la partie si Pac-Man a épuisé toutes ses vies ou s'il
# parvient à manger tous les fruits

while pacman.nb_vies > 0 and fruit.nb > 0:
    pacman.jouer(fruit, gomme, fantome)
    fantome.jouer(pacman, fruit)
    time.sleep(0.5)    # petite pause dans l'exécution du script
    print()

txt_pt = str(pacman.points) + " points"
if pacman.points == 0:
    txt_pt = "0 point"

if pacman.nb_vies == 0:
    print("Pac-Man a perdu avec", txt_pt, "! Victoire des fantômes...")
else:
    print("Victoire de Pac-Man avec", txt_pt, "! Tous les fruits ont été mangés.")
