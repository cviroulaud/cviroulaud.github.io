#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   Wednesday 16 February 2022 14:11
"""
import unittest
from fonctions_verif import *
from constantes import *


class Test(unittest.TestCase):

    def setUp(self):
        self.g_lose = [[0 for _ in range(TAILLE)] for _ in range(TAILLE)]
        self.g_lose[1][2] = 1
        self.g_win = [[0 for _ in range(TAILLE)] for _ in range(TAILLE)]

    def test_gagnant(self):
        self.assertTrue(verifier_gagnant(self.g_win))
        self.assertFalse(verifier_gagnant(self.g_lose))

    def test_verifier_coordonnees(self):
        self.assertTrue(verifier_coordonnees(0, 0))
        self.assertTrue(verifier_coordonnees(1, 1))
        self.assertTrue(verifier_coordonnees(TAILLE-1, TAILLE-1))
        self.assertFalse(verifier_coordonnees(-1, 1))
        self.assertFalse(verifier_coordonnees(1, -1))
        self.assertFalse(verifier_coordonnees(TAILLE, 1))
        self.assertFalse(verifier_coordonnees(1, TAILLE))


if __name__ == "__main__":
    unittest.main()
