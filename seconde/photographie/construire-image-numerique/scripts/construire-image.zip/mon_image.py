#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
@Author: Christophe Viroulaud
@Time:   Lundi 20 Septembre 2021 22:21
"""

from PIL import Image
from figures import *

image = Image.new('RGB', (800, 600), (255, 255, 255))



image.show()
